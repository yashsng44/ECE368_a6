#ifndef a6_h
#define a6_h 
#include <stdio.h>  
#include <stdlib.h> 
#include <string.h> 
#include <stdbool.h>
#include <math.h>


typedef struct Node
{ 
    int node_name; // print out the ASCII representation of the numbers and characters
    int width; 
    int height;
    int org_x;
    int org_y;
    struct Node *left;
    struct Node *right;
} Node;

typedef struct Stack
{ 
    struct Node * node;
    struct Stack * next;
} Stack;

struct Stack * buildTree(char * filename);
void print_from_stack(char * filename, Stack * stack_head);
void box_and_room_coords(Node * tree_node, FILE * fol);
void print_dim_and_corner(Node * tree_node, FILE * fol);
struct Node * calculate_room_edges(Node * tree_node);
void free_stack(Stack * stack_head);
int min(int num1, int num2);
int max(int num1, int num2);
void postorder_print(Node * tree_node, FILE * fol);
void preorder_print(Node * tree_node, FILE * fol);
struct Stack * buildTree(char * filename);
struct Node * build_trio(Stack ** stack_head, char * buffer);
void free_stack(Stack * stack_head);
void free_tree(Node * root);
void add_to_stack(Stack ** stack_head, Node * new_node);
struct Node * init_node(char * buffer);
struct Node * pop_from_stack(Stack ** stack_head);
#endif